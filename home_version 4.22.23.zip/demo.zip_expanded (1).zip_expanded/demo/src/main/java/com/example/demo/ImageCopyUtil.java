package com.example.demo;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ImageCopyUtil {
    public static void copyImageToStaticFolder(String imagePath) throws IOException {
        // Get the image file as a resource
        Resource resource = new ClassPathResource(imagePath);

        // Get the static folder path
        Path staticFolderPath = Paths.get("src", "main", "resources", "static");

        // Create the static folder if it doesn't exist
        if (!Files.exists(staticFolderPath)) {
            Files.createDirectories(staticFolderPath);
        }

        // Copy the image file to the static folder
        String fileName = resource.getFilename();
        Path staticFilePath = staticFolderPath.resolve(fileName);
        byte[] imageBytes = FileCopyUtils.copyToByteArray(resource.getInputStream());
        Files.write(staticFilePath, imageBytes);
    }
}

