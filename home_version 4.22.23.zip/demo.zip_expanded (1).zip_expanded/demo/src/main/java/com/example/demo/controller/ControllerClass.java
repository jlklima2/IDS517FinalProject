package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.example.demo.Account;
import com.example.demo.Customer;
import com.example.demo.Transaction;
import com.example.demo.myService;

@Controller
public class ControllerClass {

	//connects the service class to the controller class
	@Autowired
    private myService myService;
	
	//shows the account page and fills the accounts table with accounts from the database
	@GetMapping("/")
	public String showloginPage(Model model) {
		model.addAttribute("accountNumberInput", new Account());
		return "index";
	}
	
	//shows the account page and fills the accounts table with accounts from the database
	@GetMapping("/aboutus/{accountNumber}")
	public String showaboutusPage(@PathVariable("accountNumber") int accountNumber, Model model) {
        model.addAttribute("loggedinAccountNumber", accountNumber);
		return "aboutus";
	}
	//shows the account page and fills the accounts table with accounts from the database
		@RequestMapping("/home/{accountNumber}")
		public String homePage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account loggedinAccount = myService.getaccountobject(accountNumber);
			model.addAttribute("loggedinAccount", loggedinAccount);
			model.addAttribute("loggedinCustomer", myService.populatecustomer(loggedinAccount.custNumber));
			return "home";
		}
		
	//shows the account page and fills the accounts table with accounts from the database
	@GetMapping("/admin")
	public String admin(Model model) {
		List<Account> accountlist = myService.getAllAccounts();
        model.addAttribute("accountlist", accountlist);
		return "admin";
	}
	
	//shows the account page and fills the accounts table with accounts from the database
		@GetMapping("/viewmyaccounts/{accountNumber}")
		public String showmyAccounts(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
	        List<Account> myaccounts = myService.getmyaccounts(act, false);
	        model.addAttribute("myaccounts", myaccounts);
	        model.addAttribute("loggedinAccountNumber", accountNumber);
			return "viewmyaccounts";
		}
		
	//shows the customer view  page and fills the customer table with customers from the database
	@RequestMapping("/customerview")
	public String viewcustomers(Model model) {
		List<Customer> customerlist = myService.getAllCustomers();
        model.addAttribute("customerlist", customerlist);
		return "customerview";
	}
	
	//shows the account page and fills the accounts table with accounts from the database
		@GetMapping("/transactionhistory/{accountNumber}")
		public String transaction(@PathVariable("accountNumber") int accountNumber, Model model) {
			List<Transaction> transactionhist = myService.getAllTransactions(accountNumber);
	        model.addAttribute("transactionhist", transactionhist);
	        model.addAttribute("loggedinAccountNumber", accountNumber);
			return "transactionhistory";
		}
	
	// shows the add new form page
	@RequestMapping("/new-account")
	 public String addaccount(Model model) {
		model.addAttribute("Account", new Account());
		//shows the incremented account number from the database on the screen but does not allow for edit
		int x = myService.incrementaccount();
		x=x+1;
		String y = "Account Number: " + x;
		model.addAttribute("accountnumber", y);
        return "new-account";
    }
	
	// shows the add new form page
		@RequestMapping("/new-customer")
		 public String addcustomer(Model model) {
	        model.addAttribute("Customer", new Customer());
	      //shows the incremented customer number from the database on the screen but does not allow for edit
	        int x = myService.incrementcustomer();
			x=x+1;
			String y = "Customer Number: " + x;
			model.addAttribute("custnumber", y);
	        return "new-customer";
	    }
	// deletes the account from the table on the account page
	@RequestMapping("/delete/{accountNumber}")
	public String delete(@PathVariable("accountNumber") int accountNumber) {
		myService.delete(accountNumber);
		return "redirect:/admin";
	}
	//shows the account details of the account that the edit request was made on
	@RequestMapping("/edit/account/{accountNumber}")
	public String populateAccount(@PathVariable("accountNumber") int accountNumber, Model model) {
	        Account act = myService.populateaccount(accountNumber);
	        model.addAttribute("act", act);
	        return "update-account";
	    }
	//shows the customer details of the customer that the edit request was made on
	@RequestMapping("/edit/customer/{custNumber}")
	public String populateCustomer(@PathVariable("custNumber") int custNumber, Model model) {
	        Customer cust = myService.populatecustomer(custNumber);
	        model.addAttribute("cust", cust);
	        return "update-customer";
	    }
	
	// updates the account details in the table on the account page and database
    @RequestMapping(value = "/updateaccount", method = RequestMethod.POST)
    public String updateAccount(@ModelAttribute("Account") Account act) {
        myService.updateaccount(act);
        return "redirect:/admin";
    }
	// updates the customer details in the table on the customer page and database
    @RequestMapping(value = "/updatecustomer", method = RequestMethod.POST)
    public String updateCustomer(@ModelAttribute("Customer") Customer cust) {
        myService.updatecustomer(cust);
        return "redirect:/customerview";
    }
    
	@RequestMapping("/deposit/{accountNumber}")
	public String showdepositPage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			 act.amount=0;
	        model.addAttribute("act", act);
	        return "deposit";
	    }
	@RequestMapping("/withdraw/{accountNumber}")
	public String showwithdrawPage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			 act.amount=0;
	        model.addAttribute("act", act);
	        return "withdraw";
	    }
	
	@RequestMapping("/updatephone/{accountNumber}")
	public String showphonePage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			Customer cust = myService.getcustomerobject(act.custNumber);
			model.addAttribute("act", act);
	        model.addAttribute("cust", cust);
	        return "updatephone";
	    }
	
	@RequestMapping("/updateemail/{accountNumber}")
	public String showemailPage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			Customer cust = myService.getcustomerobject(act.custNumber);
			model.addAttribute("act", act);
	        model.addAttribute("cust", cust);
	        return "updateemail";
	    }
	
	@RequestMapping("/changepin/{accountNumber}")
	public String showpinPage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			model.addAttribute("act", act);
	        return "changepin";
	    }
    
	@RequestMapping("/transfer/{accountNumber}")
	public String showtransferPage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			 act.amount=0;
	        model.addAttribute("act", act);
	        List<Account> myaccounts = myService.getmyaccounts(act, true);
	        model.addAttribute("myaccounts", myaccounts);
	        return "transfer";
	    }
	
	@RequestMapping("/paybill/{accountNumber}")
	public String showpaybillPage(@PathVariable("accountNumber") int accountNumber, Model model) {
			Account act = myService.getaccountobject(accountNumber);
			 act.amount=0;
	        model.addAttribute("act", act);
	        List<Account> myaccounts = myService.getmyaccounts(act, true);
	        model.addAttribute("myaccounts", myaccounts);
	        return "paybill";
	    }
 // deposits the entered amount into the logged in account
    @PostMapping("/deposit")
    public String deposit(@ModelAttribute("Account") Account act) {
        myService.deposit(act.amount, act);
        return "redirect:/home/" + act.accountNumber;
    }
    // withdraws the entered amount from the logged in account
    @PostMapping("/withdraw")
    public String withdraw(@ModelAttribute("Account") Account act) {
        myService.withdraw(act.amount, act);
        return "redirect:/home/" + act.accountNumber;
    }
    // transfers the money from the logged in account to the selected account
    @PostMapping("/transfer")
    public String transfer(@ModelAttribute("Account") Account act) {
    	myService.withdraw(act.amount, act);
    	Account taccount = myService.getaccountobject(act.accountOptions);
    	 myService.deposit(act.amount, taccount);
        return "redirect:/home/" + act.accountNumber;
    }
    
 // transfers the money from the logged in account to the selected account
    @PostMapping("/paybill")
    public String paybill(@ModelAttribute("Account") Account act) {
    	myService.withdraw(act.amount, act);
    	Account paccount = myService.getaccountobject(act.accountOptions);
    	 myService.withdraw(act.amount, paccount);
        return "redirect:/home/" + act.accountNumber;
    }
    // saves the new account and populates the fields in the table on the account page
		@RequestMapping(value = "/saveaccount", method = RequestMethod.POST)
		public String saveAccount(@ModelAttribute("Account") Account act, Model model) {
			myService.save(act);
			return "redirect:/admin";
	}

	
 // saves the new customer and populates the fields in the table on the customer page
    @RequestMapping(value = "/savecustomer", method = RequestMethod.POST)
    public String saveCustomer(@ModelAttribute("Customer") Customer cust) {
        myService.save(cust);
        return "redirect:/customerview";
    }
    
    // updates the customer details in the table on the customer page and database
    @PostMapping("/updatephone")
    public String updatephone(@ModelAttribute("Account") Account act, @ModelAttribute("Customer") Customer cust) {
        myService.updatephone(cust);
        return "redirect:/home/" +act.accountNumber;
    }
    
    // updates the customer details in the table on the customer page and database
    @PostMapping("/updateemail")
    public String updateemail(@ModelAttribute("Account") Account act, @ModelAttribute("Customer") Customer cust) {
        myService.updateemail(cust);
        return "redirect:/home/" + act.accountNumber;
    }
    
    // updates the customer details in the table on the customer page and database
    @PostMapping("/changepin")
    public String changepin( @ModelAttribute("Account") Account act) {
    	myService.changepin(act);
        return "redirect:/home/" + act.accountNumber;
    }
    // saves the new customer and populates the fields in the table on the customer page
    @PostMapping("/homeaction")
    public String homeaction(@ModelAttribute("Account") Account act) {
		List<Account> accountlist = myService.getAllAccounts();
		boolean isValid = false;
		for (int i=0; i<accountlist.size(); i++ ) {
			if (accountlist.get(i).accountNumber == act.accountNumber && accountlist.get(i).pin.equals(act.pin)) {
				isValid=true;
				break;
			}
		}
		if (isValid) {
	        return "redirect:/home/" + act.accountNumber;
		}
		else {
        return "redirect:/";
		}
    }
 // saves the new customer and populates the fields in the table on the customer page
    @GetMapping("/verifyuser")
    public String verifyuser(Model model) {
    	model.addAttribute("verifyuser", new Account());
		return "verifyuser";
    }
    // saves the new customer and populates the fields in the table on the customer page
    @PostMapping("/verifyaction")
    public String verifyuseraction(@ModelAttribute("Account") Account act) {
		List<Account> accountlist = myService.getAllAccounts();
		boolean isValid = false;
		for (int i=0; i<accountlist.size(); i++ ) {
			if (accountlist.get(i).accountNumber == act.accountNumber && accountlist.get(i).custNumber == act.custNumber) {
				act = accountlist.get(i);
				isValid=true;
				break;
			}
		}
		if (isValid) {
	        return "redirect:/forgotpin/" + act.accountNumber;
		}
		else {
			return "redirect:/verifyuser";
		}
    }
 // saves the new customer and populates the fields in the table on the customer page
    @GetMapping("/forgotpin/{accountNumber}")
    public String forgotpin(@PathVariable("accountNumber") int accountNumber, Model model) {
    	Account act = myService.getaccountobject(accountNumber);
    	model.addAttribute("act", act);
		return "forgotpin";
    }
    // updates the customer details in the table on the customer page and database
    @PostMapping("/forgotpin")
    public String forgotpin( @ModelAttribute("Account") Account act) {
    	myService.changepin(act);
        return "redirect:/";
    }
		
	
}
