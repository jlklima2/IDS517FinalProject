package com.example.demo;

public class Customer {
	int custNumber;
	String firstName;
	String lastName;
	String email;
	String phone;
	int active;
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	//constructor for customer class 
	public Customer(int custNumber, String firstName, String lastName, String email, String phone, int active) {
		super();
		this.custNumber = custNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.active = active;
	}

	//getters and setters for each variable in the customer class to create the objects from the database
	public int getCustNumber() {
		return custNumber;
	}


	public void setCustNumber(int custNumber) {
		this.custNumber = custNumber;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public int getActive() {
		return active;
	}


	public void setActive(int active) {
		this.active = active;
	}


	@Override // to String method to create a string of customer objects
	public String toString() {
		return "Customer [custNumber=" + custNumber + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", phone=" + phone + ", active=" + active + "]";
	}
	
	
}
