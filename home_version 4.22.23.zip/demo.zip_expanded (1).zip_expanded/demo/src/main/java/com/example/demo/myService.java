package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class myService {
	//connects to the data source
	@Autowired
    private JdbcTemplate jdbcTemplate;
	public  List<Account> accounts;
	public List<Customer> customers;
	public List<Transaction> transactions;

	//creates objects in the account list from the database
    public List<Account> getAllAccounts() {
        String sql = "SELECT * FROM FlamesAtm.Account";
        accounts = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class));
        return accounts;
    }
    //creates objects in the customer list from the database
    public List<Customer> getAllCustomers() {
        String sql = "SELECT * FROM FlamesAtm.customer";
        customers = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Customer.class));
        return customers;
    }
    
  //creates objects in the account list from the database
    public List<Transaction> getAllTransactions(int accountNumber) {
        String sql = "SELECT * FROM FlamesAtm.Transaction WHERE accountNumber = " + accountNumber + " ORDER BY txn_id DESC LIMIT 10";
        transactions = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Transaction.class));
        return transactions;
    }
    //deletes the account from the database
    public void delete(int accountNumber) {
    	String sql = "delete FROM FlamesAtm.Account WHERE accountNumber = " + accountNumber + "";
    	jdbcTemplate.execute(sql);
    			
    }
    
  //populates the edit account page with the account from the database
    public Account populateaccount(int accountNumber) {
    	String sql = "Select * FROM FlamesAtm.Account WHERE accountNumber = " + accountNumber + " LIMIT 1";
    	List<Account> act = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class));
    	return act.get(0);
    	}
  //populates the edit customer page with the customer from the database
    public Customer populatecustomer(int custNumber) {
    	String sql = "Select * FROM FlamesAtm.Customer WHERE custNumber = " + custNumber + " LIMIT 1";
    	List<Customer> cust = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Customer.class));
    	return cust.get(0);
    	}
    			
    //adds the new account into the database
    public void save(Account act) {
    	String sql = "INSERT INTO FlamesAtm.Account (balance, pin, interestRate, accountType, custNumber) VALUES (" + act.balance + ",'" + act.pin + "'," + act.interestRate + ",'" + act.accountType + "','" + act.custNumber + "')";
    	jdbcTemplate.execute(sql);
    }
  //adds the new customer into the database
    public void save(Customer cust) {
    	String sql = "INSERT INTO FlamesAtm.customer (firstName, lastName, email, phone, active) VALUES ('" + cust.firstName + "','" + cust.lastName + "','" + cust.email + "','" + cust.phone + "'," + cust.active + ")";
    	jdbcTemplate.execute(sql);
    }
    
  //updates the account into the database
    public void updateaccount(Account act) {
    	String sql = "UPDATE FlamesAtm.Account SET balance = " + act.balance + ", pin = '" + act.pin + "',  interestRate = " + act.interestRate + ",  accountType = '" + act.accountType + "', custNumber = '" + act.custNumber + "' WHERE accountNumber = " + act.accountNumber + "";
    	jdbcTemplate.execute(sql);
 }
  //updates the customer into the database
    public void updatecustomer(Customer cust) {
    	String sql = "UPDATE FlamesAtm.Customer SET firstName = '" + cust.firstName + "', lastName = '" + cust.lastName + "',  email = '" + cust.email + "',  phone = '" + cust.phone + "', active = " + cust.active + " WHERE custNumber = " + cust.custNumber + "";
    	jdbcTemplate.execute(sql);
 }
    //pulls the most recent account number to increment by 1 if a new account should be added
    public int incrementaccount() {
    	String sql = "SELECT * FROM FlamesAtm.Account ORDER BY accountNumber DESC LIMIT 1";
    	List<Account> accounts = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class)); 
    	return accounts.get(0).accountNumber;
    }
    //pulls the most recent customer number to increment by 1 if a new customer should be added
    public int incrementcustomer() {
    	String sql = "SELECT * FROM FlamesAtm.Customer ORDER BY custNumber DESC LIMIT 1";
    	List<Customer> customers = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Customer.class)); 
    	return customers.get(0).custNumber;
    }
    
  //updates the account into the database
    public Account getaccountobject(int accountNumber) {
    	String sql = "SELECT * FROM FlamesAtm.Account WHERE accountNumber = " + accountNumber;
    	List<Account> accounts = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class)); 
    	return accounts.get(0);
    }
  //updates the account into the database
    public Customer getcustomerobject(int custNumber) {
    	String sql = "SELECT * FROM FlamesAtm.Customer WHERE custNumber = " + custNumber;
    	List<Customer> customers = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Customer.class)); 
    	return customers.get(0);
    }
  //updates the account into the database
    public void deposit(int amount, Account act) {
    	act.balance += amount;
    	String sql = "UPDATE FlamesAtm.Account SET balance = " + act.balance + " WHERE accountNumber = " + act.accountNumber;
    	jdbcTemplate.execute(sql);
    	String query = "insert into transaction  (debit, credit, Balance, accountNumber) values (" + amount + ", " + 0 + ", " +act.balance + ", " + act.accountNumber + ")";
    	jdbcTemplate.execute(query);
    	
    	
 }
    
    //updates the account into the database
    public void withdraw(int amount, Account act) {
    	act.balance -= amount;
    	String sql = "UPDATE FlamesAtm.Account SET balance = " + act.balance + " WHERE accountNumber = " + act.accountNumber;
    	jdbcTemplate.execute(sql);
    	String query = "insert into transaction  (debit, credit, Balance, accountNumber) values (" + 0 + "," + amount + "," +act.balance + ", " + act.accountNumber + ")";
    	jdbcTemplate.execute(query);
    }
    public List<Account> getmyaccounts(Account act, boolean isTransfer) {
    	String sql = "";
    	if (isTransfer) {
    		sql = "SELECT * FROM FlamesAtm.Account WHERE custNumber = " + act.custNumber + " AND accountType <> 'L' AND accountNumber <> " + act.accountNumber;
    	}
    	else {
    		sql = "SELECT * FROM FlamesAtm.Account WHERE custNumber = " + act.custNumber;
    	}
    	List<Account> myaccounts = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Account.class)); 
    	return myaccounts;
    	
    }
  //updates the account into the database
    public void updatephone(Customer cust) {
    	String sql = "UPDATE FlamesAtm.Customer SET phone = '" + cust.phone + "' WHERE custNumber = " + cust.custNumber;
    	jdbcTemplate.execute(sql);
 }
    
  //updates the account into the database
    public void updateemail(Customer cust) {
    	String sql = "UPDATE FlamesAtm.Customer SET email = '" + cust.email + "' WHERE custNumber = " + cust.custNumber;
    	jdbcTemplate.execute(sql);
 }
  //updates the account into the database
    public void changepin(Account act) {
    	String sql = "UPDATE FlamesAtm.Account SET pin = '" + act.pin + "' WHERE accountNumber = " + act.accountNumber;
    	jdbcTemplate.execute(sql);
 }
    
}
