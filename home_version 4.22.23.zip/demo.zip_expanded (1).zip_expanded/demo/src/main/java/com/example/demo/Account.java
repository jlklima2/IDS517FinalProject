package com.example.demo;



public class Account {
	//database variables
	public int balance;
	public double interestRate;
	public String pin;
	public int accountNumber;
	public String accountType;
	public int custNumber;
	//non database variables
	public int amount=0;
	public int accountOptions=0;
	
	
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	//constructor for account class 
	public Account(int balance, double interestRate, String pin, int accountNumber, String accountType, int custNumber, int amount, int accountOptions) {
		this.balance = balance;
		this.interestRate = interestRate;
		this.pin = pin;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.custNumber = custNumber;
		this.amount = amount;
		this.accountOptions = accountOptions;
	}
//getters and setters for each variable in the account class to create the objects from the database
	public int getbalance() {
		return balance;
	}
	public int getAccountOptions() {
		return accountOptions;
	}
	public void setAccountOptions(int accountOptions) {
		this.accountOptions = accountOptions;
	}
	public int getamount() {
		return amount;
	}

	public void setbalance(int balance) {
		this.balance = balance;
	}
	
	public void setamount(int amount) {
		this.amount = amount;
	}

	public double getinterestRate() {
		return interestRate;
	}

	public void setinterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getpin() {
		return pin;
	}

	public void setpin(String pin) {
		this.pin = pin;
	}

	public int getaccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getaccountType() {
		return accountType;
	}

	public void setaccountType(String accountType) {
		this.accountType = accountType;
	}

	public int getcustNumber() {
		return custNumber;
	}

	public void setcustNumber(int custNumber) {
		this.custNumber = custNumber;
	}

	@Override // to String method to create a string of account objects
	public String toString() {
		return "Account [balance=" + balance + ", interestRate=" + interestRate + ", pin=" + pin + ", accountNumber="
				+ accountNumber + ", accountType=" + accountType + ", custNumber=" + custNumber + "]";
	}
	
	
}
