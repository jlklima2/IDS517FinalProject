package com.example.demo;

public class Transaction {
	public int txn_ID;
	public float credit;
	public float debit;
	public float balance;
	public String txn_timestamp;
	public int accountNumber;
	
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(int txn_ID, float credit, float debit, float balance, String txn_timestamp, int accountNumber) {
		this.txn_ID = txn_ID;
		this.credit = credit;
		this.debit = debit;
		this.balance = balance;
		this.txn_timestamp = txn_timestamp;
		this.accountNumber = accountNumber;
	}


	public int gettxn_ID() {
		return txn_ID;
	}


	public void settxn_ID(int txn_ID) {
		this.txn_ID = txn_ID;
	}


	public float getCredit() {
		return credit;
	}


	public void setCredit(float credit) {
		this.credit = credit;
	}


	public float getDebit() {
		return debit;
	}


	public void setDebit(float debit) {
		this.debit = debit;
	}


	public float getBalance() {
		return balance;
	}


	public void setBalance(float balance) {
		this.balance = balance;
	}


	public String gettxn_timestamp() {
		return txn_timestamp;
	}


	public void settxn_timestamp(String txn_timestamp) {
		this.txn_timestamp = txn_timestamp;
	}


	public int getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

}
